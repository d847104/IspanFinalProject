<template>
    <h3>購物訂單管理</h3>

    <h2>訂單編號</h2>
    <h2>訂單時間</h2>
    <h2>總金額</h2>
    <h2>訂單狀態</h2>
    <h2>送出訂單</h2>
    <h2>賣家確認</h2>
    <h2>已出貨</h2>
    <h2>已到貨</h2>
    <h2>完成訂單</h2>
    <h2>取消訂單</h2>
    <h2>我要退貨</h2>
    <h2>訂單明細</h2>
    <div class="progress" role="progressbar" aria-label="Success example" aria-valuenow="25" aria-valuemin="0"
        aria-valuemax="100">
        <div class="progress-bar bg-success" style="width: 25%">25%</div>
    </div>
    <div class="progress" role="progressbar" aria-label="Info example" aria-valuenow="50" aria-valuemin="0"
        aria-valuemax="100">
        <div class="progress-bar bg-info text-dark" style="width: 50%">50%</div>
    </div>
    <div class="progress" role="progressbar" aria-label="Warning example" aria-valuenow="75" aria-valuemin="0"
        aria-valuemax="100">
        <div class="progress-bar bg-warning text-dark" style="width: 75%">75%</div>
    </div>
    <div class="progress" role="progressbar" aria-label="Danger example" aria-valuenow="100" aria-valuemin="0"
        aria-valuemax="100">
        <div class="progress-bar bg-danger" style="width: 100%">100%</div>
    </div>

    <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="..." class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                        additional content. This content is a little bit longer.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>
    </div>


</template>

<script setup>

</script>

<style></style>