import Component from "vue-flatpickr-component"
import buyerorder from "./buyerorder.vue"

export default [
    { name: "buyerorder-link", Component: buyerorder, path: "/buyer/buyerorder", title: "buyerorder" },
]