<template>
  <div class="container">
    <NavBar></NavBar>
    <RouterView></RouterView>
  </div>
</template>

<script setup>
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.js'
// import 'sweetalert2/dist/sweetalert2.min.css'
// import 'flatpickr/dist/flatpickr.css'
import NavBar from './views/NavBar.vue'
// import 'bootstrap-vue/dist/bootstrap-vue'
// import Navigation from './views/Navigation.vue'

</script>

<style></style>
