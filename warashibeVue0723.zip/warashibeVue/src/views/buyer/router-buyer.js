import BuyerOrder from "./BuyerOrder.vue"

export default [
    { name: "buyer-BuyerOrder-link", component: BuyerOrder, path: "/buyer/buyerorder", title: "BuyerOrder" },

]