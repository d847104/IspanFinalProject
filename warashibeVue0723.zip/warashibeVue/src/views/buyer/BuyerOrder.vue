<template>
    <br>
    <h3>購物訂單管理</h3>
    <div class="alert alert-dark" role="alert">
        <div class="row gx-5">
            <div class="col-md-4">
                <div class="p-3">
                    <h5>訂單編號</h5>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3">
                    <h5>訂單時間</h5>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3">
                    <h5>總金額</h5>
                </div>
            </div>
        </div>
    </div>
    <h5>訂單狀態</h5>
    <div class="alert alert-secondary" role="alert">
        <div class="container overflow-hidden text-center">
            <div class="row gx-5 align-items-center">
                <div class="col-md-10 ">
                    <div class="p-3">
                        <div class="progress" role="progressbar" aria-label="Example 20px high" aria-valuenow="25"
                            aria-valuemin="0" aria-valuemax="100" style="height: 20px">
                            <div class="progress-bar" style="width: 25%">送出訂單</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="p-3">
                        <a href="#" class="btn btn-secondary btn-sm d-block mb-2">完成訂單</a>
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">取消訂單</a>
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">我要退貨</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <h5>賣家：</h5>
    <div class="alert alert-light" role="alert">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10">
                    <div class="card mb-3">
                        <div class="row g-0" style="max-width: 500px;">
                            <div class="col-md-4">
                                <img src="/src/img/馬克杯21569.jpg" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">【單色馬克杯】</h5>
                                    <p class="card-text">商品介紹內容</p>
                                    <br><br>
                                    <p class="card-text"><small class="text-body-secondary">更新時間:</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="p-4">
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">訂單明細</a>
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">評價</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <h5>賣家：</h5>
    <div class="alert alert-light" role="alert">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10">
                    <div class="card mb-3">
                        <div class="row g-0" style="max-width: 500px;">
                            <div class="col-md-4">
                                <img src="/src/img/馬克杯84089.jpg" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">【單色馬克杯】</h5>
                                    <p class="card-text">商品介紹內容</p>
                                    <br><br>
                                    <p class="card-text"><small class="text-body-secondary">更新時間:</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="p-4">
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">訂單明細</a>
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">評價</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <h5>賣家：</h5>
    <div class="alert alert-light" role="alert">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10">
                    <div class="card mb-3">
                        <div class="row g-0" style="max-width: 500px;">
                            <div class="col-md-4">
                                <img src="/src/img/馬克杯27117.jpg" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">【單色馬克杯】</h5>
                                    <p class="card-text">商品介紹內容</p>
                                    <br><br>
                                    <p class="card-text"><small class="text-body-secondary">更新時間:</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="p-4">
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">訂單明細</a>
                        <a href="#" class="btn btn-outline-secondary btn-sm d-block mb-2">評價</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


</template>

<script setup>

</script>

<style></style>