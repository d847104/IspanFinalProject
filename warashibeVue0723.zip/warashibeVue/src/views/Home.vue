<template>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                <nav class="nav flex-column w-2 p-3">
                    <a class="nav-link" href="#">服飾</a>
                    <a class="nav-link" href="#">圖書</a>
                    <a class="nav-link" href="#">3C用品</a>
                    <a class="nav-link" href="#">生活用品</a>
                    <a class="nav-link" href="#">家電用品</a>
                    <a class="nav-link" href="#">運動用品</a>
                    <a class="nav-link" href="#">寵物用品</a>
                    <a class="nav-link active" aria-current="page" href="#">嬰幼兒用品</a>
                    <!-- <a class="nav-link disabled" aria-disabled="true">Disabled</a> -->
                </nav>
            </div>
           
            <div class="col-md-10">
                <div class="container ">
                    <br>
                    <div class="text-left">
                        <h4>熱門商品</h4>
                    </div>
                    <div class="card d-inline-flex p-2 mb-3 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯8807.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">【馬克杯】</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>

                    <div class="card d-inline-flex p-2 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯21569.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>
                    <div class="card d-inline-flex p-2 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯36344.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>
                    <div class="card d-inline-flex p-2 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯8807.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>
                    <div class="card d-inline-flex p-2 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯21569.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>
                </div>
                <br>
                <div class="container">
                    <div class="text-left">
                        <h4>推薦給您</h4>
                    </div>
                    <div class="card d-inline-flex p-2 mb-3 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯84089.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>

                    <div class="card d-inline-flex p-2 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯88795.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>
                    <div class="card d-inline-flex p-2 mx-2" style="max-width: 225px;">
                        <img src="/src/img/馬克杯27117.jpg" class="card-img-top" alt="...">

                        <div class="card-body">
                            <h5 class="card-title">馬克杯</h5>
                            <p class="card-text">「單色馬克杯」『單色馬克杯』【單色馬克杯】</p>
                            <a href="#" class="btn btn-secondary btn-sm mx-1">商品介紹</a>
                            <a href="#" class="btn btn-secondary btn-sm ">加入購物車</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style></style>